/* LR_surface.sl - This is the standard plastic surface for RenderMan Interface.
 * Modified to match LightWave's stardard shaders.
 *
 * This shader is ment to be used with Light-R
 */

surface
LR_surface (float Ka = 1;
            float Kd = .5;
            float Ks = 0;
            float roughness = .1;
            float translucency = 0;
            float luminosity = 0;
            float reflection = 0;
            float eta = 1;
	      color specularcolor = 1;
            float doubleSide = 1;
   output varying color spec = 0;
   output varying color col = 0;
   output varying color diffu = 0;
   output varying color refle = 0;)
{
    //color spec = 0;
    color trans = 0;
    color i = 1;
    normal Nf = faceforward (normalize(N),I, normalize(N));
    vector R, T;
    float Kr;
    float Kt;
    color env = 0;

    vector V = normalize(I);

    /* an IF statment is faster than compute specular() and then multiply the result by 0 */

    if(Ks > 0){
        spec = specularcolor * Ks * phong(Nf, -V, roughness);
    }

    if(translucency > 0){
        trans = diffuse(-Nf) * translucency;
    }

    if(doubleSide == 1){ /* if the polygon doesn't have two sides, make the rear transparent */
       if(N.Nf < 0 ){
         i = color( 0 );
       }
    }

    diffu = Kd*diffuse(Nf);
    col = Cs; // this variable spits only the color of the surface
    Ci = Cs * (Ka*ambient() + diffu + luminosity) + trans + spec;
    diffu += trans;

    // Trace the reflection / refraction
    if (reflection > 0.01){
       Nf = faceforward (normalize(N), V);
       vector D = vtransform ("world", reflect (V, Nf));
       refle = reflection * color environment ("raytrace", D);
	 Ci += refle;
       //Ci += env;
    }

    Oi = Os * i;
    if (comp(Oi, 1) > 0.01 && eta != 1){
       fresnel( V, Nf, (I.Nf < 0 ? 1/eta : eta), Kr, Kt, R, T); // Compute the reflection and refraction angle
       //env = color environment("raytrace", T);	
       env += trace(P,T);
       Ci += env;
       Oi = 1;
    }

    Ci *= Os * i;
}

