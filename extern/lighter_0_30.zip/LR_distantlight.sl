/* LR_distantlight.sl - A modified version of the standard distant light source for RenderMan Interface.
   
   This light simulates the distance attenuation, just like LightWave. 
*/

light
LR_distantlight ( float intensity = 1;
   	         color lightcolor = 1;
	         point from = point "shader" (0,0,0);
	         point to = point "shader" (0,0,1); 
               string shadowname = "";
               float samples = 16;
               float width = 1;
               float blur = 0;
               float falloff = 6;
               float range = 1;)
{
  float atten = 1;

  solar (to-from, 0){
            if( falloff == 6 )      /* no falloff, LW default */
                  atten = 1;
            else if( falloff == 5 ) /* linear falloff*/
                  atten = 1 - length(L) / range;
            else if( falloff == 4 )
                  atten = range / length(L); /* inverse of distance */
            else if( falloff == 3)
                  atten = pow(range / length(L), 2); /* square of inverse distance */

      Cl = atten * intensity * lightcolor;
      if (shadowname != "")
         Cl *= 1 - shadow(shadowname, Ps, "blur", blur, "width", width);
  }
}