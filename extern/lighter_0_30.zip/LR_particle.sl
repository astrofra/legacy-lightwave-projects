surface LR_particle( float Ka = .5, 
                           Kd = .5;
  uniform color particleColor = (.7, .7, .7); )
{

	normal Nf = faceforward( normalize(N), I );

	Oi = Os;
	Ci = Oi * particleColor * ( Ka*ambient() + Kd*diffuse(Nf) );

}

