Light-R V 0.30 (alpha) February 2005


Light-R is a LightWave 7 & 8 plug-in for Windows/Intel. This program exports LW camera, lights (with shadow maps) and polygons into a sequence of RIB (RenderMan Interface Bytestream) files, ready to be used by a RenderMan renderer (Photorealistic RenderMan, Aqsis, 3Delight, etc.). Light-R needs many features to be considered complete but now is more than just a prototype. The polygons have attached a simple matte shader with color information but not smooth normals (using the LW SDK is not an efficient task to get the averaged normals). I've been testing generated RIB files with Aqsis and 3Delight, in the next version I'll try to support more renderers.

Use this program freely and please send me feedback about bugs and features you need or want.


How to use Light-R

Install Light-R just like any other LightWave plug-in, this procedure will load into memory two plug-ins, one is the main exporter and the other just a tool that helps you indicate wich objects will be exported as Subdivision Surfaces (LW subpatches will be frozen), this tag will be saved with the scene. 

Compile with your particular renderer the light shaders included with this distribution, these shaders will illuminate your scene very similar to LightWave's spot and point light. The shaders were kindly borrowed and modified from the Aqsis project. If any light is casting shadows using a shadow map instead of raytracing, Light-R will write an individual RIB to make depth map files to be converted and used by the provided light shaders. At this moment rendering isn't automatic but you don't need to modify the RIB files.

My intention is to make Light-R easy to use and the program will try to use any current LightWave properties in terms to make rendering easy and transparent, and the files (the shadow map RIBs specially) will be saved in the default LW content directory.

Feature list:

Objects
- An object with a tag "_SDS_ON" will be exported as Subdivision Surface (this tag is created using RenderMan SDS plug-in)
- Objects with parameter "cast shadows" off will no be included in the shadow RIB
- color for every polygon
- different shader for every LW surface
- Surface parameters supported: Color, diffuse, specular, double side on/off, translusence.
- Automatic reflection if supported by the renderer.
- Exports particle systems as points and blobs

Lights
- Lighting match LW setup (except ambient intensity and color)
- Shadow maps
- Support for cached shadow maps
- Shadow maps and raytraced shadows are now supported specific for Aqsis, 3Delight, AIR and Pixie. (I can't make RenderDotC work right now).
- Shadow RIB optimization using ReadArchive

Camera
- Support for Depth of Field

Rendering
- Quantize now supported
- Render passes with AOV (specular, color, diffuse and reflection)

TODO list:

- Export average normals (at this moment no smooth shading is possible)
- Work textures and shaders (must)
- Support for Level of Detail and Motion Blur
- Write patches (if possible)
- Select geometry for area lights (desirable)
- Scene optimization with ReadArchive and level of detail (desirable)
- All the important features a standard RenderMan compliant renderer wants
- I'm open to suggestions

Cheers, bugs and complains are well received.

Felipe Esquivel

titus@deathfall.com
http://www.deathfall.com

----------------
Changelog

0.30 alpha (23/2/2005): Exports particles systems as points and blobs.
                        Changed back the status from beta to alpha, the program isn't buggy just no feature completed

0.29 beta (1/31/2005): Support for AOV rendering
                       Added Quantize and eyesplits

0.28 beta (12/31/2004): Support for Pixar's RenderMan
                        Fixed a strange bug. When using layered objects the : character in the name
                        stops writing shadow map files.


0.27 beta (10/18/2004): Minor change in LR_shadowspot.sl due complains of the new 3Delight version. 
                        Code cleaning, soon to support motion blur and binary RIBs.


0.26 beta

Added (3/9/2004): Surface parameters exported: Color, diffuse, specular, double side on/off.
                  Surface shader LW_plastic.sl, matches LW default surface.
                  Specular glossines is the same in LW and renderman
                  Shader LR_plastic.sl renamed to LR_surface.sl
0.25 beta

Added (1/9/2004): Automatic creation of a batch render file.
                  4 bugs fixed.

0.24 beta(7/2004): More bug crunching and support for Pixie
                   Support for point and distant lights
0.22 beta

Added (7/2004): Changes in the UI
                Support for different renderers (Aqsis, 3Delight & AIR, more renderers only if I can get them)
                Internal code changes relevant only for future developers

0.21 beta

Added (6/2004): A simple but important bug fixed
                Cache of shadow maps implemented

0.2 beta

Added (5/2004): Polygon color exported
                Polygonal objects exported when scene includes a _SDS_ON tag
		Support for shadowmaps
		Correct lighting conditions with LR_shadowspot.sl
		Depth of Field information
		Minor bugs fixed

0.1c beta

Fixed (2/7/2003):  Objects without polygons are excluded (eg. NULLS)
Fixed (3/11/2003): Object exported as PointsPolygons instead of just Polygons
Added (3/23/2003): Objects with subpatches exported as SDS (doesn't render well with BMRT) - 0.1b





