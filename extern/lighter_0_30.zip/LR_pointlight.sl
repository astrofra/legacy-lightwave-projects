/* LR_pointlight.sl - Standard point light source for RenderMan Interface with falloff.
 */

light
LR_pointlight (float intensity = 1;
      	   color lightcolor = 1;
	         point from = point "shader" (0,0,0);
               string shadowname = "";
               float falloff = 6;
               float range = 1;
               float blur = 1;
               float width = 1;)
{
  float atten;
 
  illuminate (from){
        if( falloff == 6 )      /* no falloff, LW default */
            atten = 1;
        else if( falloff == 5 ) /* linear falloff*/
            atten = 1 - length(L) / range;
        else if( falloff == 4 )
            atten = range / length(L); /* inverse of distance */
        else if( falloff == 3)
            atten = pow(range / length(L), 2); /* square of inverse distance */

      Cl = atten * intensity * lightcolor; /* / (L . L); */
      if (shadowname != "")
          Cl *= 1 - shadow(shadowname, Ps, "blur", blur, "width", width);
  }
}
