light LR_shadowspot(
    float intensity = 1;
    color lightcolor = 1;
    point from = point "shader" (0, 0, 0);
    point to =   point "shader" (0, 0, 1);
    float coneangle = radians(30);
    float conedeltaangle = radians(5);
    float beamdistribution = 2;
    string shadowname = "";
    float samples = 16;
    float width = 1;
    float blur = 0;
    float falloff = 6;
    float range = 1;)
{
    float atten, cosangle;
    //antes era uniform point A... pero 3delight 2.1 requiere este cambio
    uniform vector A = (to - from) / length(to - from);
    uniform float cosoutside = cos(coneangle);
    uniform float cosinside  = cos(coneangle - conedeltaangle);

    illuminate (from, A, coneangle) {
        cosangle = (L . A) / length(L);
            if( falloff == 6 )      /* no falloff */
                  atten = 1;
            else if( falloff == 5 ) /* linear falloff*/
                  atten = 1 - length(L) / range;
            else if( falloff == 4 )
                  atten = range / length(L); /* inverse distance */
            else if( falloff == 3)
                  atten = pow(range / length(L), 2); /* square inverse distance */
            else if( falloff == 2 )
			atten = pow(cosangle, beamdistribution) / (L . L);
		else if( falloff == 1 )
			atten = pow(cosangle, beamdistribution) / (length(L)/2);
		else
			atten = pow(cosangle, beamdistribution);
			
        atten *= smoothstep(cosoutside, cosinside, cosangle);
        Cl = atten * intensity * lightcolor;
        if (shadowname != "")
            Cl *= 1 - shadow(shadowname, Ps, "blur", blur, "width", width);
    }
}
