/*
 * File: lwfog.sl
 * This file is part of the LightMan distribution
 * Copyright (C) 2001-2002 Timm Dapper
 * http://www.td-grafik.de
 */
 
volume
lwfog (float mindistance = 0, maxdistance = 1;
	float minamount = 0, maxamount = 1;
	float fogtype = 0;
	color background = 0;)
{
    float d = 0, da;
    vector Iw = vtransform("world", I);
    d = clamp ((length(Iw) - mindistance) / (maxdistance - mindistance), 0, 1);
    if (fogtype == 1) {         /* NONLINEAR1 */
        d = 2 * d * (1 - d) + sin(acos(1 - d)) * d;
    } else if (fogtype == 2) {  /* NONLINEAR2 */
        d = sin(acos(1 - d));
    }
    da = minamount * (1 - d) + maxamount * d;
    Ci = mix (Ci, background, da);
}
