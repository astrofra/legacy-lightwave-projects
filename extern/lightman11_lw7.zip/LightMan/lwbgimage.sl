/*
 * File: lwbackground.sl
 * This file is part of the LightMan distribution
 * Copyright (C) 2001-2002 Timm Dapper
 * http://www.td-grafik.de
 */

surface
lwbgimage ( string texturename = "";  )
{
    Ci = color texture(texturename);
    Oi = 0;
}

