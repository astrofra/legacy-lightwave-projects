/*
 * File: lwbackground.sl
 * This file is part of the LightMan distribution
 * Copyright (C) 2001-2002 Timm Dapper
 * http://www.td-grafik.de
 */

imager
lwbackground ( color zenithcolor = color(0, 0.16, 0.31),
                     skycolor = color(0.47, 0.71, 0.94),
                     groundcolor = color(0.2, 0.16, 0.12),
                     nadircolor = color(0.39, 0.31, 0.24);
               float skysqueeze = 2.0,
                     groundsqueeze = 2.0;
               string texturename = "";  )
{
    point Plookup;
    if (alpha < 1.0) {
        if (texturename != "") {
            Plookup = transform("raster", "NDC", point(xcomp(P), ycomp(P), 0));
            Ci += (1-alpha) * color texture(texturename, xcomp(Plookup), ycomp(Plookup));
        } else {
            Ci += (1-alpha) * zenithcolor;
        }
    }
}

