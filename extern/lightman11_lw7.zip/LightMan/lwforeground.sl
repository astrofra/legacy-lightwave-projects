surface
lwforeground (string texturename = ""; string alphaname = "" )
{
    // I'm not sure how to handle the alpha channel...
    
    Oi = 0;
    if (texturename != "") {
	Ci = texture(texturename);
    } else {
	Ci = color(0);
    }
}

