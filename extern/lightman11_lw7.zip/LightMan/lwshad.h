/*
 * File: lwshad.h
 * This file is part of the LightMan distribution
 * Copyright (C) 2001-2002 Timm Dapper
 * http://www.td-grafik.de
 *
 * Last change: 04/30/02 td
 *
 */

#ifndef LWSHAD__H____
#define LWSHAD__H____

#define SQRT2 1.414213562373095048801688724
#define HALF_SQRT2 0.707106781186547524400844362

#define SQRT3 1.732050808
#define HALF_SQRT3 0.86602540378443864676372317075
#define THIRD_SQRT3 0.57735026918962576450914878050

#ifndef PI
#define PI 3.1415927
#endif

#if defined(RDC) || defined(PRMAN)
float isshadowray() { return 0; }
#endif

#ifndef snoise
/*
 * Signed noise -- the original Perlin kind with range (-1,1) We prefer
 * signed noise to regular noise mostly because its average is zero.
 * We define three simple macros:
 *   snoise(p) - Perlin noise on either a 1-D (float) or 3-D (point) domain.
 *   snoisexy(x,y) - Perlin noise on a 2-D domain.
 *   vsnoise(p) - vector-valued Perlin noise on either 1-D or 3-D domain.
 */
#define snoise(p) (2 * (float noise(p)) - 1)
#define snoisexy(x,y) (2 * (float noise(x,y)) - 1)
#define vsnoise(p) (2 * (vector noise(p)) - 1)
#endif

#define sqr(x) ((x)*(x))


float _contrast(float in; float c)
{
    return 0.5 + (in - 0.5) * c;
}

float dist(point P)
{
    return sqrt(P.P);
}

/*
#ifdef RDRIVE

point cellnoise( point p )
{
   float           f;
   unsigned int    i;
   point result = 0;

   f = xcomp(p);
   if (f < 0.0)
      f -= 1;
   i = P[(unsigned int)(f)&0x7ff];
   setxcomp(result, R[i]);

   f = ycomp(p);
   if (f < 0.0)
      f -= 1;
   i = P[P[i] + (unsigned int)(f)&0x7ff];
   setycomp(result, R[i]);

   f = zcomp(p);
   if (f < 0.0)
      f -= 1;
   i = P[P[i] + (unsigned int)(f)&0x7ff];
   setzcomp(result, R[i]);

   return result;
}

#endif
*/

/***************************************************************************
 * Voronoi cell noise (a.k.a. Worley noise) functions
 *
 * These functions assume that space is filled with "features" (points
 * of interest).  There are interesting patterns we can make by
 * figuring out which feature we are closest to, or to what extent
 * we're on the boundary between two features.  Several varieties of
 * these computations are below, categorized by the dimension of their
 * domains, and the number of close features they are interested in.
 *
 * All these functions have similar inputs:
 *   P      - position to test (for 3-D varieties; 2-D varieties use ss,tt)
 *   jitter - how much to jitter the cell center positions (1 is typical,
 *             smaller values make a more regular pattern, larger values
 *             make a more jagged pattern; use jitter >1 at your risk!).
 * And outputs:
 *   f_n    - distance to the nth nearest feature (f1 is closest, f2 is
 *            the distance to the 2nd closest, etc.)
 *   pos_n  - the position of the nth nearest feature.  For 2-D varieties,
 *            these are instead spos_n and tpos_n.
 ***************************************************************************/

/* Voronoi cell noise (a.k.a. Worley noise) -- 3-D, 1-feature version. */
void
voronoi_f1_3d (point P;
	       float jitter;
	       output float f1;
	       output point pos1;
    )
{
	uniform float i, j, k;
    point thiscell = point (floor(xcomp(P))+0.5, floor(ycomp(P))+0.5,
			    floor(zcomp(P))+0.5);
	point testcell, pos;
	vector offset;
	float dist;
    f1 = 1000;
    for (i = -1;  i <= 1;  i += 1) {
        for (j = -1;  j <= 1;  j += 1) {
            for (k = -1;  k <= 1;  k += 1) {
		        testcell = thiscell + vector(i,j,k);
                pos = testcell + jitter * (vector cellnoise (testcell) - 0.5);
		        offset = pos - P;
                dist = offset . offset; /* actually dist^2 */
                if (dist < f1) {
                    f1 = dist;  pos1 = pos;
                }
            }
	}
    }
    f1 = sqrt(f1);
}


/* Voronoi cell noise (a.k.a. Worley noise) -- 3-D, 2-feature version. */
void
voronoi_f1f2_3d (point P;
		 float jitter;
		 output float f1;  output point pos1;
		 output float f2;  output point pos2;
    )
{
    point thiscell = point (floor(xcomp(P))+0.5, floor(ycomp(P))+0.5,
			    floor(zcomp(P))+0.5);
	uniform float i, j, k;
	point testcell, pos;
	vector offset;
	float dist;
    f1 = f2 = 1000;
    for (i = -1;  i <= 1;  i += 1) {
        for (j = -1;  j <= 1;  j += 1) {
            for (k = -1;  k <= 1;  k += 1) {
		        testcell = thiscell + vector(i,j,k);
                pos = testcell +
		           jitter * (vector cellnoise (testcell) - 0.5);
		        offset = pos - P;
                dist = offset . offset; /* actually dist^2 */
                if (dist < f1) {
                    f2 = f1;  pos2 = pos1;
                    f1 = dist;  pos1 = pos;
                } else if (dist < f2) {
                    f2 = dist;  pos2 = pos;
		}
            }
	}
    }
    f1 = sqrt(f1);  f2 = sqrt(f2);
}


color lwdifference(color first; color second)
{
    float n;
    color final;
    for (n = 0; n < 3; n += 1)
	setcomp(final, n, abs(comp(first, n) - comp(second, n)));
    return final;
}

void lwplanarprojection(point Ptest; float axis; output float ss, tt)
{
    if (axis <= 0) {		/* X Axis */
        ss = zcomp(Ptest) + 0.5;
        tt = 0.5 - ycomp(Ptest);
    } else if (axis <= 1) {	/* Y Axis */
        ss = xcomp(Ptest) + 0.5;
        tt = 0.5 - zcomp(Ptest);
    } else {			/* Z Axis */
        ss = xcomp(Ptest) + 0.5;
        tt = 0.5 - ycomp(Ptest);
    }
}

void lwcylindricalprojection(point Ptest; float axis, wwa; output float ss, tt)
{
    point Sn = Ptest;
    float tmp1, tmp2;

    if (axis <= 0) { 		/* X Axis */
        tt = 0.5 - xcomp(Sn);
        ss = (atan(-ycomp(Sn), -zcomp(Sn)) / (2 * PI) + 0.75) * wwa;
    } else if (axis <= 1) { 	/* Y Axis */
        tt = 0.5 - ycomp(Sn);
        ss = (atan(zcomp(Sn), xcomp(Sn)) / (2 * PI) + 0.75) * wwa;
    } else { 			/* Z Axis */
        tt = 0.5 - zcomp(Sn);
        ss = (atan(-ycomp(Sn), xcomp(Sn)) / (2 * PI) + 0.75) * wwa;
    }
}

void lwsphericalprojection(point Ptest; float axis, wwa, hwa; output float ss, tt)
{
    point Sn = normalize(Ptest);
    float tmp1, tmp2;
    if (axis <= 0) { 		/* X Axis */
        tt = 1.0 - ((acos(-Sn.point(1, 0, 0)) / PI) * hwa);
        ss = (atan(-ycomp(Sn), -zcomp(Sn)) / (2 * PI) + 0.75) * wwa;
    } else if (axis <= 1) { 	/* Y Axis */
        tt = 1.0 - ((acos(-Sn.point(0, 1, 0)) / PI) * hwa);
        ss = (atan(zcomp(Sn), xcomp(Sn)) / (2 * PI) + 0.75) * wwa;
    } else { 			/* Z Axis */
        tt = 1.0 - ((acos(-Sn.point(0, 0, 1)) / PI) * hwa);
        ss = (atan(-ycomp(Sn), xcomp(Sn)) / (2 * PI) + 0.75) * wwa;
    }
}

void lwsphericalprojection_old(point Ptest; float axis, wwa, hwa; output float ss, tt)
{
    point Sp, Se, Sn = normalize(Ptest);
    float tmp1, tmp2;
    if (axis <= 0) { 		/* X Axis */
        Sp = point(1, 0, 0);
        Se = point(0, 0, -1);
    } else if (axis <= 1) { 	/* Y Axis */
        Sp = point(0, 1, 0);
        Se = point(0, 0, -1);
    } else { 			/* Z Axis */
        Sp = point(0, 0, 1);
        Se = point(0, 1, 0);
    }

    tmp1 = acos(-Sn.Sp);
    tt = 1.0 - ((tmp1 / PI) * hwa);

    tmp2 = (acos((Se.Sn)/sin(tmp1))) / (2*PI);
    if (((Sp^Se).Sn) > 0)
        ss = tmp2 * wwa;
    else
        ss = (1.0 - tmp2) * wwa;
}

void lwcubicprojection(point Ptest; normal Ntest; output float ss, tt)
{
    if (abs(xcomp(Ntest)) > abs(ycomp(Ntest))) {
        if (abs(xcomp(Ntest)) > abs(zcomp(Ntest))) {
            lwplanarprojection(Ptest, 0, ss, tt);
        } else {
            lwplanarprojection(Ptest, 2, ss, tt);
        }
    } else {
        if (abs(ycomp(Ntest)) > abs(zcomp(Ntest))) {
            lwplanarprojection(Ptest, 1, ss, tt);
        } else {
            lwplanarprojection(Ptest, 2, ss, tt);
        }
    }
}

point lwtexcoord(vector scal, position, rotation; point Ptrans)
{
    matrix tm = 1;
#ifdef RDRIVE
    tm = matrix(1, 0, 0, 0,  0, 1, 0, 0,  0, 0, 1, 0,  -xcomp(position), -ycomp(position), -zcomp(position), 1) * tm;
    tm = matrix(cos(-zcomp(rotation)), sin(-zcomp(rotation)), 0, 0,  -sin(-zcomp(rotation)), cos(-zcomp(rotation)), 0, 0,  0, 0, 1, 0,  0, 0, 0, 1) * tm;
    tm = matrix(1, 0, 0, 0,  0, cos(xcomp(rotation)), sin(xcomp(rotation)), 0,  0, -sin(xcomp(rotation)), cos(xcomp(rotation)), 0,  0, 0, 0, 1) * tm;
    tm = matrix(cos(-ycomp(rotation)), 0, -sin(-ycomp(rotation)), 0,  0, 1, 0, 0,  sin(-ycomp(rotation)), 0, cos(-ycomp(rotation)), 0,  0, 0, 0, 1) * tm;
    tm = matrix(1/xcomp(scal), 0, 0, 0,  0, 1/ycomp(scal), 0, 0,  0, 0, 1/zcomp(scal), 0,  0, 0, 0, 1) * tm;
#else
    tm = translate(tm, -position);
    tm = rotate(tm, -zcomp(rotation), vector(0.0, 0.0, 1.0)); /* bank    */
    tm = rotate(tm, xcomp(rotation), vector(0.0, 1.0, 0.0));  /* heading */
    tm = rotate(tm, -ycomp(rotation), vector(1.0, 0.0, 0.0)); /* pitch   */
    tm = scale(tm, vector(1.0) / scal);
#endif
    return transform(tm, Ptrans);
}

float lwnoise(point Ptest)
{
    return noise(Ptest);
}

void lwbrick(point PtestIn; normal Nn;
             float axis; float thickness; float fuzzy_edge_width;
             vector Pwidth; vector I;
             output float opacity)
{
    varying point Pmod = 0;
    varying point Ptest = 0;
    varying float fuzzmax = 0.0;
    varying point Pfuzz = 0.0;
    varying float Nfactor = 0;

    float mth_half = thickness * .5;
    float few = fuzzy_edge_width;

    float x = 0, y = 0, z = 0, xy = 0;
    float Atemp = 0;

    if(axis <= 0) {
	Ptest = (ycomp(PtestIn), zcomp(PtestIn), xcomp(PtestIn));
    } else if(axis <= 1) {
	Ptest = (zcomp(PtestIn), xcomp(PtestIn), ycomp(PtestIn));
    } else if(axis <= 2) {
	Ptest = (xcomp(PtestIn), ycomp(PtestIn), zcomp(PtestIn));
    } else {}


    Nfactor = abs(Nn.I) / length(I);
    setxcomp(Pfuzz, 0.5 * xcomp(Pwidth) / Nfactor);
    setycomp(Pfuzz, 0.5 * ycomp(Pwidth) / Nfactor);
    setzcomp(Pfuzz, 0.5 * zcomp(Pwidth) / Nfactor);

    fuzzmax = max(xcomp(Pfuzz), max(ycomp(Pfuzz), zcomp(Pfuzz)));

    /* Get the place in the pattern where we're sampling */
    if(mod(zcomp(Ptest), 1) < 0.5)
	    setxcomp(Ptest, xcomp(Ptest)+0.5);

    if(mod(ycomp(Ptest), 1) > 0.5)
	    setxcomp(Ptest, xcomp(Ptest)+0.5);

    setxcomp(Pmod, mod(xcomp(Ptest), 1));
    setycomp(Pmod, mod(ycomp(Ptest)*2, 1));
    setzcomp(Pmod, mod(zcomp(Ptest)*2, 1));

    /* If the filter width is small enough, compute the pattern color */
    if (fuzzmax <= 0.7) {
	/* require minimum fuzziness according to fuzzy_edge_width */
#ifndef RDRIVE
        Pfuzz = max(Pfuzz, point(few, few, few));
#else
        Pfuzz = point(max(xcomp(Pfuzz), few), max(ycomp(Pfuzz), few), max(zcomp(Pfuzz), few));
#endif
        x = (smoothstep(mth_half, mth_half+xcomp(Pfuzz), xcomp(Pmod)) - smoothstep (1-mth_half-xcomp(Pfuzz), 1-mth_half, xcomp(Pmod)));
        y = (smoothstep(mth_half, mth_half+ycomp(Pfuzz), ycomp(Pmod)) - smoothstep (1-mth_half-ycomp(Pfuzz), 1-mth_half, ycomp(Pmod)));
        z = (smoothstep(mth_half, mth_half+zcomp(Pfuzz), zcomp(Pmod)) - smoothstep (1-mth_half-zcomp(Pfuzz), 1-mth_half, zcomp(Pmod)));
/*        Atemp = mix (1, 0, x*y*z);*/
        Atemp = 1 - x*y*z;
        /* Gradually fade in the average color when we get close to the limit */
#ifndef RDRIVE
        opacity *= mix (Atemp, 0.5, smoothstep (.3, .7, fuzzmax));
#else
        opacity *= Atemp * (1 - smoothstep (.3, .7, fuzzmax)) + 0.5 * smoothstep (.3, .7, fuzzmax);
#endif
    } else { /* otherwise, only use the average color */
        opacity *= 0.5;
    }
}

void lwbumparray(point PtestIn; normal Nn;
                 float radius; float spacing;
                 vector Pwidth; vector I;
                 output float opacity)
{
    varying point Pmod = 0;
    varying point Ptest = PtestIn;
    varying float fuzzmax = 0.0;
    varying point Pfuzz = 0.0;
    varying float Nfactor = 0;
    varying float xtile, ytile, ztile;
    varying float factor = 1;


    float tilewidth, tileradius, tilediameter;
    float ss, tt, uu;
    float ttile, stile, utile;
    float swidth, twidth, sfuzz, tfuzz;
    float in;
    float rad = radius * 1.0 / spacing;

    Ptest = PtestIn / spacing;
    Ptest -= vector(0, 0.1, 0.5);

    tileradius = THIRD_SQRT3;
    tilewidth  = 2 * tileradius;
    tilediameter = 1.5 * tileradius;



    uu = mod (zcomp(Ptest), tilediameter) / tilediameter;
    utile = floor(zcomp(Ptest) / tilediameter);

    if(mod(utile, 2) == 1) {
	tt = mod (ycomp(Ptest), tilediameter) / tilediameter;
	ttile = floor (ycomp(Ptest) / tilediameter);

    	if (mod (ttile * 0.5, 1) == 0.5) {
            ss = xcomp(Ptest) / HALF_SQRT3 + tilewidth * 0.5;
    	}
    	else {
            ss = xcomp(Ptest) / HALF_SQRT3;
	}
    } else {
	tt += 0.5 * tilediameter;
	tt = mod (ycomp(Ptest), tilediameter) / tilediameter;
	ttile = floor (ycomp(Ptest) / tilediameter);

    	if (mod (ttile * 0.5, 1) == 0) {
            ss = xcomp(Ptest) / HALF_SQRT3 + tilewidth * 0.5;
    	}
    	else {
            ss = xcomp(Ptest) / HALF_SQRT3;
	}
    }

    stile = floor (ss / tilewidth);
    ss = mod (ss, tilewidth) / tilewidth;

    if(fuzzmax < 0.5) {} else {}

    in = smoothstep(0, sqr(rad), sqr(ss-0.5) + sqr(tt-0.5) + sqr(uu-0.5));
    in -= step(sqr(rad), sqr(ss-0.5) + sqr(tt-0.5) + sqr(uu-0.5));

    opacity *= 0.25*in;
}

void lwcheckerboard(point PtestIn; normal Nn;
                    vector Pwidth; vector I;
                    output float opacity)
{
    varying point Pfuzz = 0.0;
    varying float Nfactor = 0;
    varying float fuzzmax = 0;
    varying point Pmod = 0;
    varying point Ptest = PtestIn;

    float x = 0, y = 0, z = 0, xy = 0;
    float Atemp = 0;

    Nfactor = abs(Nn.I) / length(I);
    setxcomp(Pfuzz, 0.5 * xcomp(Pwidth) / Nfactor);
    setycomp(Pfuzz, 0.5 * ycomp(Pwidth) / Nfactor);
    setzcomp(Pfuzz, 0.5 * zcomp(Pwidth) / Nfactor);

    fuzzmax = max(xcomp(Pfuzz), max(ycomp(Pfuzz), zcomp(Pfuzz)));

    /* Get the place in the pattern where we're sampling */
    setxcomp(Pmod, mod(xcomp(Ptest), 1));
    setycomp(Pmod, mod(ycomp(Ptest), 1));
    setzcomp(Pmod, mod(zcomp(Ptest), 1));

    /* If the filter width is small enough, compute the pattern color */
    if (fuzzmax <= 0.7) {
        x = ((smoothstep(.5, .5 + xcomp(Pfuzz), xcomp(Pmod))) + (1 - smoothstep (0, xcomp(Pfuzz), xcomp(Pmod))));
        y = ((smoothstep(.5, .5 + ycomp(Pfuzz), ycomp(Pmod))) + (1 - smoothstep (0, ycomp(Pfuzz), ycomp(Pmod))));
        z = ((smoothstep(.5, .5 + zcomp(Pfuzz), zcomp(Pmod))) + (1 - smoothstep (0, zcomp(Pfuzz), zcomp(Pmod))));

	xy = x*y + (1-x)*(1-y);
        Atemp = xy*z + (1-xy)*(1-z);

        /* Gradually fade in the average color when we get close to the limit */
#ifndef RDRIVE
        opacity *= mix (Atemp, 0.5, smoothstep (.3, .7, fuzzmax));
#else
        opacity *= Atemp * (1 - smoothstep (.3, .7, fuzzmax)) + 0.5 * smoothstep (.3, .7, fuzzmax);
#endif
    } else { /* otherwise, only use the average color */
        opacity *= 0.5;
    }
}

void lwcrumple(point PtestIn; normal Nn;
            float frequencies; uniform float small_powers;
            vector Pwidth; vector I;
            output float opacity)
{
    varying point Ptest = PtestIn * 1.5;
    varying vector disp;
    varying point pos1;
    varying float f1 = 0.0, f1_temp = 0.0;
    uniform float lacunarity = 2.0, amp = 1, fac = 1;
    uniform float i;

    /* compute fBm based on voronoi_f1_3d function */
    for(i = 0; i < frequencies; i += 1) {
	voronoi_f1_3d(Ptest, 1.0, f1_temp, pos1);
	f1 += amp * sqr(f1_temp);
	fac += sqr(amp);
	amp *= small_powers;
	Ptest *= lacunarity;
    }
/*
    Ptest += 0.3 * vfBm(2*Ptest, 0, frequencies-1, 2, small_powers);
*/
/*    voronoi_f1_3d(Ptest, 1.0, f1, pos1);
*/
/*    f1 /= 2 * sqrt(fac);
*/
    f1 /= 1.5 * sqrt(fac);
    f1 = _contrast(f1, 0.75);
    opacity *= smoothstep(0.0, 0.8, f1);

}

void lwcrust(point PtestIn; normal Nn;
            float coverage; float ledgeLevel; float ledgeWidth;
            vector Pwidth; vector I;
            output float opacity)
{
    opacity *= 1.0;
}

void lwdots(point PtestIn; normal Nn;
            float diameter; float fuzzy_edge_width;
            vector Pwidth; vector I;
            output float opacity)
{
    varying point Pmod = 0;
    varying point Ptest = PtestIn;
    varying float fuzzmax = 0.0;
    varying point Pfuzz = 0.0;
    varying float Nfactor = 0;

    float in;
    float radius = diameter * .5;
    float few = fuzzy_edge_width * .95;

/*    Ptest -= vector(.5);*/

    Nfactor = abs(Nn.I) / length(I);
    setxcomp(Pfuzz, 0.5 * xcomp(Pwidth) / Nfactor);
    setycomp(Pfuzz, 0.5 * ycomp(Pwidth) / Nfactor);
    setzcomp(Pfuzz, 0.5 * zcomp(Pwidth) / Nfactor);
    fuzzmax = max(xcomp(Pfuzz), max(ycomp(Pfuzz), zcomp(Pfuzz)));

    /* Get the place in the pattern where we're sampling */
    setxcomp(Pmod, mod(xcomp(Ptest), 1));
    setycomp(Pmod, mod(ycomp(Ptest), 1));
    setzcomp(Pmod, mod(zcomp(Ptest), 1));

    if(fuzzmax > 0.0) {} else {}

    in = 1 - smoothstep(sqr(radius), sqr(radius+few), sqr(xcomp(Pmod)-0.5) + sqr(ycomp(Pmod)-0.5) + sqr(zcomp(Pmod)-0.5));
    opacity *= in;
}

void lwfracnoise(point PtestIn; normal Nn;
                 float frequencies; float contrast; float small_powers;
                 output float opacity)
{
    varying point Ptest = PtestIn;
    varying float sum = 0, amp = 1, fac = 0, lacunarity = 1.0/small_powers;
    uniform float i;
    varying float fuzzmax = 0.0;
    varying float Atemp = 0.0;

    if(fuzzmax < 1.0) {} else {}

    lacunarity = 2.0;  /* seems that this should be fixed... */

    for(i = 0; i < frequencies; i += 1) {
	sum += amp * snoise(Ptest);
	fac += sqr(amp);
	amp *= small_powers;
	Ptest *= lacunarity;
    }

    /* "remap" Atemp to approx. [0,1] */
    if( frequencies > 1 )
	Atemp = sum / (0.5 * sqrt(fac));
    else
	Atemp = sum / sqrt(0.5);

    Atemp += 1.0;
    Atemp *= 0.5;

    Atemp = _contrast(Atemp, contrast);
    opacity *= clamp(Atemp, 0, 1);
}

void lwgrid(point PtestIn; normal Nn;
            float thickness; float fuzzy_edge_width;
            vector Pwidth; vector I;
            output float opacity)
{
    varying point Pmod = 0;
    varying point Ptest = PtestIn;
    varying float fuzzmax = 0.0;
    varying point Pfuzz = 0.0;
    varying float Nfactor = 0;

    float mth_half = thickness * .5;
    float few = fuzzy_edge_width * .5;

    float x = 0, y = 0, z = 0, xy = 0;
    float Atemp = 0;

    Nfactor = abs(Nn.I) / length(I);
    setxcomp(Pfuzz, 0.25 * xcomp(Pwidth) / Nfactor);
    setycomp(Pfuzz, 0.25 * ycomp(Pwidth) / Nfactor);
    setzcomp(Pfuzz, 0.25 * zcomp(Pwidth) / Nfactor);

    fuzzmax = max(xcomp(Pfuzz), max(ycomp(Pfuzz), zcomp(Pfuzz)));

    Ptest *= 2;

    /* Get the place in the pattern where we're sampling */
    setxcomp(Pmod, mod(xcomp(Ptest), 1));
    setycomp(Pmod, mod(ycomp(Ptest), 1));
    setzcomp(Pmod, mod(zcomp(Ptest), 1));

    if (fuzzmax <= 0.5) {} else {}

    /* If the filter width is small enough, compute the pattern color */
    if (fuzzmax <= 0.8) {
	/* require minimum fuzziness according to fuzzy_edge_width */
#ifndef RDRIVE
        Pfuzz = max(Pfuzz, point(few, few, few));
#else
        Pfuzz = point(max(xcomp(Pfuzz), few), max(ycomp(Pfuzz), few), max(zcomp(Pfuzz), few));
#endif

        x = (smoothstep(mth_half, mth_half+xcomp(Pfuzz), xcomp(Pmod)) - smoothstep (1-mth_half-xcomp(Pfuzz), 1-mth_half, xcomp(Pmod)));
        y = (smoothstep(mth_half, mth_half+ycomp(Pfuzz), ycomp(Pmod)) - smoothstep (1-mth_half-ycomp(Pfuzz), 1-mth_half, ycomp(Pmod)));
        z = (smoothstep(mth_half, mth_half+zcomp(Pfuzz), zcomp(Pmod)) - smoothstep (1-mth_half-zcomp(Pfuzz), 1-mth_half, zcomp(Pmod)));
        Atemp = 1 - x * y * z;
        /* Gradually fade in the average color when we get close to the limit */
#ifndef RDRIVE
        opacity *= mix (Atemp, 0.5, smoothstep (.4, .8, fuzzmax));
#else
        opacity *= Atemp * (1 - smoothstep (.4, .8, fuzzmax)) + 0.5 * smoothstep (.4, .8, fuzzmax);
#endif
    } else { /* otherwise, only use the average color */
        opacity *= 0.5;
    }
}

void lwhoneycomb(point PtestIn; normal Nn;
                 float axis; float thickness; float fuzzy_edge_width;
                 vector Pwidth; vector I;
                 output float opacity)
{
    point Ptest, Pfuzz, Pmod;
    point Nf;
    color Ct, Ctile;
    float tilewidth, tileradius;
    float ss, tt;
    float ttile, stile;
    float x, y;
    float mortar, mortarwidth;
    float swidth, twidth, sfuzz, tfuzz, fuzzmax;
    float mw2;
    float tileindex;
    float stain, scuff;
    float ks;
    float Nfactor;

    if(axis <= 0) {
	Ptest = (ycomp(PtestIn), zcomp(PtestIn), xcomp(PtestIn));
    } else if(axis <= 1) {
	Ptest = (zcomp(PtestIn), xcomp(PtestIn), ycomp(PtestIn));
    } else if(axis <= 2) {
	Ptest = (xcomp(PtestIn), ycomp(PtestIn), zcomp(PtestIn));
    } else {}

/*    Ptest -= vector(0, 0.65, 0);*/

    /* Determine how wide in s-t space one pixel projects to */
    Nfactor = abs(Nn.I) / length(I);
    Nfactor = 1;  /* in LGHexTile */
    setxcomp(Pfuzz, 0.5 * xcomp(Pwidth) / Nfactor);
    setycomp(Pfuzz, 0.5 * ycomp(Pwidth) / Nfactor);
    setzcomp(Pfuzz, 0.5 * zcomp(Pwidth) / Nfactor);

    fuzzmax = max(xcomp(Pfuzz), max(ycomp(Pfuzz), zcomp(Pfuzz)));

    sfuzz = tfuzz = max(fuzzmax, fuzzy_edge_width * 1.5);

    tileradius = 2.0 / 3.0;
    mortarwidth = thickness * .5;

    tilewidth = tileradius * 1.7320508;  /* sqrt(3) */
    tilewidth = 4.0 / 3.0;
    tt = mod (ycomp(Ptest), 1.5 * tileradius);
    ttile = floor (ycomp(Ptest) / (1.5 * tileradius));
    if (mod (ttile * 0.5, 1) == 0.5)
        ss = xcomp(Ptest) / HALF_SQRT3 + tilewidth * 0.5;
    else
        ss = xcomp(Ptest) / HALF_SQRT3;
    stile = floor (ss / tilewidth);
    ss = mod (ss, tilewidth);
    mortar = 0;
    mw2 = mortarwidth/2;
    if (tt < tileradius) {
        mortar =  1 - (smoothstep(mw2, mw2 + sfuzz, ss) *
		          (1 - smoothstep(tilewidth - mw2 - sfuzz, tilewidth - mw2, ss)));
    } else {
        x = tilewidth/2 - abs (ss - tilewidth/2);
        y = 1.7320508 * (tt - tileradius);
        if (y > x) {
            if (mod (ttile * 0.5, 1) == 0.5)
                stile -= 1;
            ttile += 1;
            if (ss > tilewidth * 0.5)
                stile += 1;
	    }
	    mortar = (smoothstep (x - 1.73 * mw2 - tfuzz, x - 1.73 * mw2, y) *
	         (1 - smoothstep (x + 1.73 * mw2, x + 1.73 * mw2 + tfuzz, y)));
    }
    opacity *= mortar;
}

void lwmarble(point PtestIn; normal Nn;
            float axis; float frequencies; float turbulence; float veinSpacing; float veinSharpness;
            vector Pwidth; vector I;
            output float opacity)
{
    opacity *= 1.0;
}

void lwripples(point PtestIn; normal Nn;
            float waveSources; uniform float waveLength; uniform float waveSpeed; float anim_time;
            vector Pwidth; vector I;
            output float opacity)
{
    varying point Ptest = PtestIn;
    varying float x;
    varying float amp = 0;
    uniform float i;
    uniform float k = 2 * PI / waveLength;
    uniform float w = k * waveSpeed * 30;

    if(waveSources <= 1) {
    	x = dist(Ptest - vector(0, 0, 0));
	amp += sin(k * x + w * anim_time);
    } else if(waveSources > 1) {
    	x = dist(Ptest + vector(0, 0, 0.75));
	amp += sin(k * x + w * anim_time);
    	x = dist(Ptest - vector(0, 0, 0.75));
	amp += sin(k * x + w * anim_time + PI);
    }
    if(waveSources > 2) {
	x = dist(Ptest - vector(0.75, 0, 0));
	amp += sin(k * x + w * anim_time + PI);
    }
    if(waveSources > 3) {
	x = dist(Ptest + vector(0.75, 0, 0));
	amp += sin(k * x + w * anim_time);
    }
    if(waveSources > 4) {
	x = dist(Ptest - vector(0.75, 0, 0.75));
	amp += sin(k * x + w * anim_time);
    }
    if(waveSources > 5) {
	x = dist(Ptest + vector(0.75, 0, 0.75));
	amp += sin(k * x + w * anim_time);
    }
    if(waveSources > 6) {
	x = dist(Ptest - vector(-0.75, 0, 0.75));
	amp += sin(k * x + w * anim_time);
    }
    if(waveSources > 7) {
	x = dist(Ptest + vector(-0.75, 0, 0.75));
	amp += sin(k * x + w * anim_time);
    }

    opacity *= 0.5 + 0.5 * amp / waveSources;
}

void lwsmoky1(point PtestIn; normal Nn;
            float frequencies; float contrast; float smallPower; float turbulence;
            vector Pwidth; vector I;
            output float opacity)
{
    opacity *= 1.0;
}

void lwsmoky2(point PtestIn; normal Nn;
            float frequencies; float contrast; float smallPower; float turbulence;
            vector Pwidth; vector I;
            output float opacity)
{
    opacity *= 1.0;
}

void lwsmoky3(point PtestIn; normal Nn;
            float frequencies; float contrast; float smallPower; float turbulence;
            vector Pwidth; vector I;
            output float opacity)
{
    opacity *= 1.0;
}

void lwturbulence(point PtestIn; normal Nn;
                  float frequencies; float contrastIn; float small_powers;
                  output float opacity)
{
    varying point Ptest = PtestIn;
    varying float sum = 0, amp = 1, fac = 0, lacunarity = 1/small_powers;
    uniform float i;
    varying float fuzzmax = 0.0;
    varying float Atemp = 0.0;
    varying float contrast = 1.0;

    if(fuzzmax < 1.0) {} else {}

    lacunarity = 2.0;  /* seems that this should be fixed... */
    contrast = 1.0;

    sum += amp * (noise(Ptest));
    fac += sqr(amp);
    amp *= small_powers;
    Ptest *= lacunarity;

    for(i = 0; i < frequencies; i += 1) {
	sum += amp * (0.6 * (snoise(Ptest)) + 0.35);
	fac += sqr(amp);
	amp *= small_powers;
	Ptest *= lacunarity;
    }

    /* "remap" Atemp to approx. [0,1] */
    if( frequencies > 0 ) {
	Atemp = sum / (min(1.5, (1.3 + 0.1 * (frequencies-1))) * sqrt(fac));
	Atemp = Atemp / (0.75 + 0.5 * smoothstep(0.3, 0.7, small_powers));
    }
    else {
	Atemp = sum / 1.0;
    }

    Atemp = _contrast(Atemp, 1.5);

    contrast = 0.5 * abs(contrastIn);

    if(contrastIn >= 0)
	Atemp = 0.04 + 0.92 * smoothstep( 0.5 * contrastIn , 1 - contrastIn * 0.5, Atemp);
    else {
	sum  = 0.5 * smoothstep(0, contrast, Atemp);
	sum += 0.5 * (1-smoothstep(0, contrast, 1-Atemp));
	Atemp = sum;
    }
    opacity *= clamp(Atemp, 0, 1);
}

void lwunderwater(point PtestIn; normal Nn;
            float waveSources; float waveLength; float waveSpeed; float bandSharpness; float anim_time;
            vector Pwidth; vector I;
            output float opacity)
{
    opacity *= 1.0;
}

void lwveins(point PtestIn; normal Nn;
            float coverage; float ledgeLevel; float ledgeWidth;
            vector Pwidth; vector I;
            output float opacity)
{
    varying point Ptest = PtestIn;
    varying point pos1, pos2;
    varying float f1, f2;
    varying float min, max;

    if(coverage <= -0.18) {
	opacity *= 0;
    } else if(coverage >= 1.4) {
	opacity *= 1;
    } else {
	voronoi_f1f2_3d(Ptest, 1, f1, pos1, f2, pos2);

    	/* do a linear interpolation of min/max parameters for smoothstep
           based on lw-param coverage
           lw-params ledgeLevel and ledgeWidth seems to be useless */
    	min = .03 + .7 * coverage;
    	max = .12 + .83 * coverage;
    	opacity *= 1 - smoothstep(min, max, f2 - f1);
    }
}

void lwwood(point PtestIn; normal Nn;
            float axis; float frequencies; float turbulence; float ringSpacing; float ringSharpness;
            vector Pwidth; vector I;
            output float opacity)
{
    point Ptest = PtestIn;
    float ss = 0.0, tt = 0.0, r;
    varying float amp = 1, fac = 0, gain = 0.5;
    varying vector sum = vector(0);
    uniform float i;

    /* Perturb Texture Lookup Point */
    for(i = 0; i < frequencies; i += 1) {
	sum += amp * vsnoise((1/amp)*Ptest);
	fac += amp;
	amp *= gain;
    }
    Ptest += turbulence/fac * sum;

    /* compute radial distance r from PtestIn to axis of "tree" */
    if (axis <= 0) { 		/* X Axis */
	ss = zcomp(Ptest);
	tt = -ycomp(Ptest);
    } else if (axis <= 1) { 	/* Y Axis */
	ss = xcomp(Ptest);
	tt = -zcomp(Ptest);
    } else { 			/* Z Axis */
	ss = xcomp(Ptest);
	tt = -ycomp(Ptest);
    }
    r = sqrt(sqr(ss) + sqr(tt));

    /* map radial distance r nto ring position [0, 1] */
    r /= ringSpacing;
    r += 0.5;
    r = (1 - ringSharpness * 0.5) + mod(r, 1) * ringSharpness * 0.5;

    /* use ring position r to select wood color */
    opacity = smoothstep(0.0, 0.95, r) - smoothstep(0.98, 1.0, r);
}

void lwfBm(point PtestIn; normal Nn;
           float frequencies; float contrast; float small_powers;
           output float opacity;)
{
    varying point Ptest = PtestIn;
    varying float sum = 0, amp = 1, fac = 0, lacunarity = 1/small_powers;
    uniform float i;
    varying float fuzzmax = 0.0;
    varying float Atemp = 0.0;

    if(fuzzmax < 1.0) {} else {}

    lacunarity = 1.9;

    if(frequencies < 1) {
	sum += amp * 1.1 * abs(snoise(Ptest));
	fac += (amp);
	amp *= small_powers;
	Ptest *= lacunarity;

        /* correct the contrast... */
	Atemp = 1.5 * sum;
	sum  = 0.5 * smoothstep(0, 0.55, Atemp);
	sum += 0.5 * (1-smoothstep(0, 0.55, 1-Atemp));
    } else {
	Ptest *= lacunarity;
	for(i = 0; i < frequencies; i += 1) {
	    sum += 0.05 + 0.9 * amp * abs(snoise(Ptest));
	    fac += (amp);
	    amp *= small_powers;
	    Ptest *= lacunarity;
	}

	/* "remap" Atemp to approx. [0,1] */
	Atemp = sum / (min(0.75 + 0.1 * (frequencies-2), 1.4) * (fac));

	Atemp = _contrast(Atemp, 1.5);
    }

    if(contrast >= 0)
	Atemp = Atemp * (1-contrast) + contrast * smoothstep( -0.1 * contrast, 1 - 0.99 * contrast, Atemp );
    else
	Atemp = Atemp * (1+contrast) - contrast * smoothstep( -0.99 * contrast, 1 - 0.15 * contrast, Atemp );

    opacity *= clamp(Atemp, 0, 1);
}

#endif