/*
 * File: lwlinearlight.sl
 * This file is part of the LightMan distribution
 * Copyright (C) 2001-2002 Timm Dapper
 * http://www.td-grafik.de
 */
 
light
lwlinearlight (float intensity = 1;
		color lightcolor = 1;
		float falloff = 0;
		float normaldistance = 1;
                output uniform float __nondiffuse = 0;
                output uniform float __nonspecular = 0;
		output uniform float __foglight = 0;)
{
    float atten = 1;
    vector Ln;
    
    illuminate (P) {
        if (falloff < 1) {    
            atten = 1.0;
        } else if (falloff < 2) {
            atten = max (0.0, 1.0 - (length(L) / normaldistance));
        } else if (falloff < 3) {
            Ln = L / normaldistance;
            atten = 1.0 / length(Ln);
        } else {
            Ln = L / normaldistance;
            atten = 1.0 / (Ln . Ln);
        }
	Cl = intensity * lightcolor * atten;
    }
}
