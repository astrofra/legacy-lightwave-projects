/*
 * File: lwspotlight.sl
 * This file is part of the LightMan distribution
 * Copyright (C) 2001-2002 Timm Dapper
 * http://www.td-grafik.de
 */

light
lwspotlight(
    float intensity = 1;
    color lightcolor = 1;
    point from = point "shader" (0, 0, 0);
    point to =   point "shader" (0, 0, 1);
    float coneangle = radians(30);
    float conedeltaangle = radians(5);
    string shadowname = "";
    string projectionimage = "";
    float samples = 16;
    float fuzz = 1;
    float bias = -1e9;
    float falloff = 0;
    float normaldistance = 1;
    output uniform float __nondiffuse = 0;
    output uniform float __nonspecular = 0;
    output uniform float __foglight = 0;)
{
    float atten = 1, cosangle;
    uniform vector A = (to - from) / length(to - from);
    uniform float cosoutside = cos(coneangle);
    uniform float cosinside  = cos(coneangle - conedeltaangle);
    varying vector Ln;

    illuminate (from, A, coneangle) {
        cosangle = (L . A) / length(L);
        if (falloff < 1) {    
            atten = 1.0;
        } else if (falloff < 2) {
            atten = max (0.0, 1.0 - (length(L) / normaldistance));
        } else if (falloff < 3) {
            Ln = L / normaldistance;
            atten = 1.0 / length(Ln);
        } else {
            Ln = L / normaldistance;
            atten = 1.0 / (Ln . Ln);
        }
            
        atten *= smoothstep(cosoutside, cosinside, cosangle);
        Cl = atten * intensity * lightcolor;
        if (shadowname != "") {
            if (bias >= 0.0) {
                Cl *= 1 - shadow(shadowname, Ps, "samples", samples,
                    "swidth", fuzz, "twidth", fuzz, "bias", bias);
            } else {
                Cl *= 1 - shadow(shadowname, Ps, "samples", samples,
                    "swidth", fuzz, "twidth", fuzz);
            }
        }
    }
}
